/*
Package pep is a Go library that implements a Policy Enforcement Point
*/
package pep
