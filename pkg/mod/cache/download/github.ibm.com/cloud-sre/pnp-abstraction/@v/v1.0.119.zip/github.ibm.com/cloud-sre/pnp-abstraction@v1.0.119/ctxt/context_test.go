package ctxt

import "testing"

func TestContext(t *testing.T) {
	// No code to test in context yet
}
