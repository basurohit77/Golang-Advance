package consts

// Git contants
const (
	// IBMgitHubEndPoint IBM Git Hub end point
	IBMgitHubEndPoint = "github.ibm.com/cloud-sre/"
)
