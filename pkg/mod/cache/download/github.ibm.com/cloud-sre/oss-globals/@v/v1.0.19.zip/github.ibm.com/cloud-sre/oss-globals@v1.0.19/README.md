# oss-globals
Contains constants and functions that will be used in different applications such as PnP,  EDB, Compass and others.
