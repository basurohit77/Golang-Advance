package main

const (
	// LoopFrequencyEnv specifies the number of minutes between adapter runs.
	LoopFrequencyEnv = "PNPNOTIFICATIONSLOOP"
)
