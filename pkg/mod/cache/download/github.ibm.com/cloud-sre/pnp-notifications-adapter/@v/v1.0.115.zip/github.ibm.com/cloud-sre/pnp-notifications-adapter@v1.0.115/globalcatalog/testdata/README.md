# Resource data

This is a directory of test data that comes from the URL https://resource-catalog.bluemix.net/api/v1?languages=%2A and follows all of the `next` links.  This is here for the purpose of automated tests to simulate data that would come from the global catalog.

All of the `next` links in this data have been substituted with the string `NEXT_LINK_TEST_PLACEHOLDER` so that while testing we can easily put in a test URL to retrieve.
