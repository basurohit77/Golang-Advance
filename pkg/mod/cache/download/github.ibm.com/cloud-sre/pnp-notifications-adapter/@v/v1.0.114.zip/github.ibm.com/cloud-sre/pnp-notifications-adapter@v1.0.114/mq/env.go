package mq

const (

	// MQURL is the message queue URL
	MQURL = "MQ_URL"
	// MQURL2 is the backup message queue URL
	MQURL2 = "MQ_URL2"
)
