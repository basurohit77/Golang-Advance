# pnp-gitnotice
Simple methods for dealing with ghe as a source for announcements and security notices.
