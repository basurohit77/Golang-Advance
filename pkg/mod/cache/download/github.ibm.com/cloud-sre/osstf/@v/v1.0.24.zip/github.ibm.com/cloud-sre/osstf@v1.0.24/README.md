# osstf
This GO library contains common code for Operational Support System Techinical Foundation tools. 

# Libraries required
* go get gopkg.in/lib/pq.v0
* go get gopkg.in/natefinch/lumberjack.v2

# To include this as a library
go get github.ibm.com/cloud-sre/osstf/...