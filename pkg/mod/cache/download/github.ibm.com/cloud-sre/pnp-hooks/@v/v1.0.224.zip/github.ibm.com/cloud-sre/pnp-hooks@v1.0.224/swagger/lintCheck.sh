#! /bin/bash

echo CHECKING api-pnp-hooks.yaml
swagger-cli validate api-pnp-hooks.yaml
