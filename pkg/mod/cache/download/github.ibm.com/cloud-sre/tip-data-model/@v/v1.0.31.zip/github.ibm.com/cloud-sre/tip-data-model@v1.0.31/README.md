# Introduction

This project contains common data definitions which are used by all TIP API producers and consumers. The master of these data structures is the Swagger Editor and documentation [from here](http://sretools.rtp.raleigh.ibm.com).
