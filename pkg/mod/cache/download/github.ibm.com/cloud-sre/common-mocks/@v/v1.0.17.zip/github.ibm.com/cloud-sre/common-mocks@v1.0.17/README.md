# common-mocks
A library for commons mocks for test purposes
