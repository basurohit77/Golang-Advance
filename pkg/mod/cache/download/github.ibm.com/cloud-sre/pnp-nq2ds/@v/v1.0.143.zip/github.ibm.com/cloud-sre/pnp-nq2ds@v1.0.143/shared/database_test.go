package shared

import (
	"log"
	"testing"
)

func TestConnectDatabase(t *testing.T) {
	log.Print("TestConnectDatabase Start")
	// err := ConnectDatabase()
	// if err != nil {
	// 	log.Print("Found error")
	// 	t.Fatal(err)
	// }
	log.Print("TestConnectDatabase DONE")
}
