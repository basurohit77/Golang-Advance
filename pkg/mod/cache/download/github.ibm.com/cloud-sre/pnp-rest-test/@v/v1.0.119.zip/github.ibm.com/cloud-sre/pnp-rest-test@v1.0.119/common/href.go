package common

// Href is a struct containing the hyperlink reference
type Href struct {
	Href string `json:"href"`
}
