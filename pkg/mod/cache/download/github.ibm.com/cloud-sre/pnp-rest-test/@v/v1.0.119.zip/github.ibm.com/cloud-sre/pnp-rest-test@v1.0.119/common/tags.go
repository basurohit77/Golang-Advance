package common

// SimpleTag Is a tag definition for tags with just an ID
type SimpleTag struct {
	ID string `json:"id"`
}
