package forms

var RunForm = `<h1>Title -  {{.Title}}</h1>


<div>{{printf "%s" .Body}}</div>
`
