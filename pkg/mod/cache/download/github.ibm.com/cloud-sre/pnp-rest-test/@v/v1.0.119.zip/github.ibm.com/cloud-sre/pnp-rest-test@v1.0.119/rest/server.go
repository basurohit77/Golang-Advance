package rest

// Server information
type Server struct {
	Token    string
	SNToken  string
	User     string
	Password string
}
