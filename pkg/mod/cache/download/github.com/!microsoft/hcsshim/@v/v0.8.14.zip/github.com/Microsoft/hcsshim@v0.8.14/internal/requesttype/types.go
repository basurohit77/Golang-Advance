package requesttype

// These are constants for v2 schema modify requests.

// RequestType const
const (
	Add    = "Add"
	Remove = "Remove"
	PreAdd = "PreAdd" // For networking
	Update = "Update"
)
