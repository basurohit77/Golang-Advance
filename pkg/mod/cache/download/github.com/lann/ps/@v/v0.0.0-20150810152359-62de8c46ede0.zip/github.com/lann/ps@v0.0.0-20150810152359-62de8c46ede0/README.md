**This is a stable fork of https://github.com/mndrix/ps; it will not introduce breaking changes.**

ps
==

Persistent data structures for Go.  See the [full package documentation](http://godoc.org/github.com/lann/ps)

Install with

    go get github.com/lann/ps
