package packr

// Version of Packr
const Version = "v2.7.1"
