package logger

// Version of the logger
const Version = "v1.0.1"
