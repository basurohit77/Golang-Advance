# Changelog

## 0.4

 * Update the name of the package from `logrus_logstash` to `logrustash`
 * Add TimeFormat to Hook
 * Replace the old logrus package path: `github.com/Sirupsen/logrus` with `github.com/sirupsen/logrus` 

## 0.3

 * Fix the Logstash format to set `@version` to `"1"`
 * Add unit-tests to logstash.go
 * Remove the assert package
 * Add prefix filtering

## Before that (major changes)

 * Update LICENSE to MIT from GPL
