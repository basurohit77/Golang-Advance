New Relic Platform Agent SDK for Go(golang)
====================

[![Build Status](https://travis-ci.org/yvasiyarov/newrelic_platform_go.png?branch=master)](https://travis-ci.org/yvasiyarov/newrelic_platform_go)

This package provide very simple interface to NewRelic Platform http://newrelic.com/platform

For example of usage see examples/wave_plugin.go

For real-word example, you can have a look at:   
https://github.com/yvasiyarov/newrelic_sphinx   
