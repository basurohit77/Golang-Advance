#!/usr/bin/env bash
p=github.com/ziutek/mymysql

go $* $p/mysql $p/native $p/thrsafe $p/autorc $p/godrv
