---
name: "Enhancement request \U0001F4A1"
about: Suggest an idea for a future version of this project
title: ''
labels: enhancement
assignees: ''

---

[NOTE]: # ( ^^ Provide a general summary of the request in the title above. ^^ )

## Summary

[NOTE]: # ( Provide a brief overview of what the new feature is all about. )

## Desired Behaviour

[NOTE]: # ( Tell us how the new feature should work. Be specific. )
[TIP]:  # ( Do NOT give us access or passwords to your New Relic account or API keys! )

## Possible Solution

[NOTE]: # ( Not required. Suggest how to implement the addition or change. )

## Additional context

[TIP]:  # ( Why does this feature matter to you? What unique circumstances do you have? )
