The examples in this directory are for the now deprecated v2 New Relic Go
Agent.  Examples for the most recent v3 version of the agent can be found in
[v3/examples](../v3/examples).
