# _integrations/nrlogxi/v1 [![GoDoc](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogxi/v1?status.svg)](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogxi/v1)

Package `nrlogxi` supports https://github.com/mgutz/logxi.

```go
import "github.com/newrelic/go-agent/_integrations/nrlogxi/v1"
```

For more information, see
[godocs](https://godoc.org/github.com/newrelic/go-agent/_integrations/nrlogxi/v1).
