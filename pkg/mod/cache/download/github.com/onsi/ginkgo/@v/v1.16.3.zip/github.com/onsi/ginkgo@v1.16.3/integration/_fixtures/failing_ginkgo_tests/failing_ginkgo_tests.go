package failing_ginkgo_tests

func AlwaysFalse() bool {
	return false
}
