// Package jwt implements JWTs per RFC 7519
package jwt
