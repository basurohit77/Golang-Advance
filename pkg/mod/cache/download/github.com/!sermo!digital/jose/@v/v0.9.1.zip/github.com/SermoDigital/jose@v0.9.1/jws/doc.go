// Package jws implements JWSs per RFC 7515
package jws
