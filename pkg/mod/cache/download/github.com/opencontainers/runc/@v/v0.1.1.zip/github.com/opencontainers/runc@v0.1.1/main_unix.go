// +build linux

package main

import _ "github.com/opencontainers/runc/libcontainer/nsenter"
