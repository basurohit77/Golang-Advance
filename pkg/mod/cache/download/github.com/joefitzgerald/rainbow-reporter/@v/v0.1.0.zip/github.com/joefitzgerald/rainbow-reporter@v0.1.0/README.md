# rainbow-reporter
A spec (https://github.com/sclevine/spec) reporter that is colorized 🌈!
