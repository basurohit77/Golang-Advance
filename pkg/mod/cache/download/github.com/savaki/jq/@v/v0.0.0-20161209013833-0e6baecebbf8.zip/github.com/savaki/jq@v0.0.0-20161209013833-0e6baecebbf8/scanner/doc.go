// Package scanner provides various utilities for parsing and extracting json data from []byte

package scanner
