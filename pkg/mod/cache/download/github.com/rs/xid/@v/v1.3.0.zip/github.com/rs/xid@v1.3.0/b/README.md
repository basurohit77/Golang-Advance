# Bytes storage

This subpackage is there to allow storage of XIDs in a binary format in, for example, a database.
It allows some data size optimisation as the 12 bytes will be smaller to store than a string.
