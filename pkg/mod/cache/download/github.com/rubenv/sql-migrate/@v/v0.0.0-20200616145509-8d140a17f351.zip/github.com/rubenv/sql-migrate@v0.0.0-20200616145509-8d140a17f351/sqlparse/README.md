# SQL migration parser

Based on the [goose](https://bitbucket.org/liamstask/goose) migration parser.

## License

This library is distributed under the [MIT](LICENSE) license.
