// (c) Copyright IBM Corp. 2021
// (c) Copyright Instana Inc. 2020

// +build go1.10

package internal

import (
	"github.com/instana/go-sensor/autoprofile/internal/pprof/profile"
)

func symbolizeProfile(p *profile.Profile) error {
	return nil
}
