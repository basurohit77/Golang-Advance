// Copyright 2020 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package replicacount contains a kio.Filter implementation of the kustomize
// ReplicaCountTransformer.
package replicacount
