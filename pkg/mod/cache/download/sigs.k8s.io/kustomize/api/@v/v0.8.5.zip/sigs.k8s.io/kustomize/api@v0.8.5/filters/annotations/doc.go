// Copyright 2020 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package annotations contains a kio.Filter implementation of the kustomize
// annotations transformer.
package annotations
