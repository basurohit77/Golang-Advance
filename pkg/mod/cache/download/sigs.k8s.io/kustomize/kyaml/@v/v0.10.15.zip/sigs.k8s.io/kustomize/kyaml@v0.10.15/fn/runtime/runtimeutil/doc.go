// Copyright 2019 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package runtimeutil contains libraries for implementing function runtimes.
package runtimeutil
