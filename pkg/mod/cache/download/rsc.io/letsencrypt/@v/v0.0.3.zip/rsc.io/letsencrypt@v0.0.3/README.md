## rsc.io/letsencrypt is superseded by [golang.org/x/crypto/acme/autocert](https://golang.org/x/crypto/acme/autocert).

The latest old rsc.io/letsencrypt is tagged v0.0.2 if you must use it.

But don't.

It hasn't been updated in years and probably carries security problems with it.

**Use [golang.org/x/crypto/acme/autocert](https://golang.org/x/crypto/acme/autocert) instead.**
