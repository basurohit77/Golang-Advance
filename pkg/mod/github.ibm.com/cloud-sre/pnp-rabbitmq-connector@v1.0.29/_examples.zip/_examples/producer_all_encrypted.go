package main

import (
	"log"

	"github.ibm.com/cloud-sre/pnp-data-encryption"
	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		url = []string{"amqp://guest:guest@192.168.99.100:5672", "amqp://guest:guest@mytesthost:5670"}
		// routingKey   = "incident"
		exchangeName = "pnp.direct"
		exchangeType = "direct"
	)

	log.SetFlags(log.LstdFlags | log.Lmicroseconds | log.Lshortfile)

	p := rabbitmq.NewProducer(url, "", exchangeName, exchangeType)

	err := p.Connect()
	if err != nil {
		log.Fatalln(err)
	}

	mymap := make(map[string]string)
	mymap["incident"] = "Incident"
	mymap["case"] = "Case"
	mymap["maintenance"] = "Maintenance"
	mymap["resource"] = "Resource"
	mymap["status"] = "Status"
	log.Println(mymap)

	for k, v := range mymap {

		p.RoutingKey = k           // e.g. incident
		p.Publishing.MessageId = v // e.g. Incident

		encMsg, err := encryption.Encrypt("test msg - " + v) // Encryption
		if err != nil {
			log.Println(err)
		}

		err = p.Produce(string(encMsg))
		if err != nil {
			log.Println(err)
		}

		log.Println("sent", v)

		// time.Sleep(10 * time.Second)

	}

}
