package main

import (
	"log"

	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		// url          = "amqp://guest:guest@192.168.99.100:5672"
		url          = []string{"amqp://guest:guest@192.168.99.100:5672", "amqp://guest:guest@mytesthost:5670"}
		routingKey   = "incident"
		exchangeName = "pnp.all.direct"
		exchangeType = "direct"
	)

	p := rabbitmq.NewProducer(url, routingKey, exchangeName, exchangeType)

	err := p.Connect()
	if err != nil {
		log.Fatalln(err)
	}

	p.Publishing.MessageId = "Incident"
	err = p.Produce("test msg - INCIDENT")
	if err != nil {
		log.Println(err)
	}

	p.RoutingKey = "case"
	p.Publishing.MessageId = "Case"
	err = p.Produce("test msg - CASE")
	if err != nil {
		log.Println(err)
	}

	p.RoutingKey = "maintenance"
	p.Publishing.MessageId = "Maintenance"
	err = p.Produce("test msg - MAINTENANCE")
	if err != nil {
		log.Println(err)
	}

	p.RoutingKey = "resource"
	p.Publishing.MessageId = "Resource"
	err = p.Produce("test msg - RESOURCE")
	if err != nil {
		log.Println(err)
	}

	p.RoutingKey = "status"
	p.Publishing.MessageId = "Status"
	err = p.Produce("test msg - STATUS")
	if err != nil {
		log.Println(err)
	}
}
