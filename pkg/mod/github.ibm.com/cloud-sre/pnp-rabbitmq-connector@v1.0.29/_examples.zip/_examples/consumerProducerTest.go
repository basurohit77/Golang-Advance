package main

import (
	"log"

	"github.com/streadway/amqp"

	encryption "github.ibm.com/cloud-sre/pnp-data-encryption"
	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		url = []string{"amqp://192.168.99.100:5672", "amqp://192.168.99.100:5670"}
		// qKey holds the list of all queues and routing keys that msgs should be consumed from
		// the string is separated by comma(","), between each comma there a pair of queue:key
		// e.g. "incident.subscription:incident", the queue name is incident.subscription and the routing key is incident
		qKey = "rabbitmq.test:test"
		// qKey         = "queueName:routingKey,queueName2:routingKey2"
		exchangeName = "pnp.direct"
		routingKey   = "test"
		exchangeType = "direct"
	)

	c := rabbitmq.NewConsumer(url, qKey, exchangeName)

	// set a consumer name, this name will show in the list of consumers in a queue it's consuming from
	c.Name = "catalog_test_conn"

	// server automatically acks a msg that is consumed from a queue
	// no need to call msg.Ack(false) if AutoAck is true
	// if not set, the default value is false
	c.AutoAck = true

	conn, ch, err := c.ConsumeWithoutReconnection(f)
	if err != nil {
		log.Fatalln(err)
	}
	defer conn.Close()
	defer ch.Close()

	p := rabbitmq.NewProducer(url, routingKey, exchangeName, exchangeType)

	// Encryption
	encMsg, err := encryption.Encrypt("test msg!! - " + routingKey)
	if err != nil {
		log.Println(err)
	}

	err = p.ProduceOnce(string(encMsg))
	if err != nil {
		log.Println(err)
	}

}

func f(msg amqp.Delivery) {
	// Decryption
	decryptedMsg, err := encryption.Decrypt(msg.Body)
	if err != nil {
		log.Println(err)
	}

	log.Printf("msg: %s", decryptedMsg)
}
