package main

import (
	"log"

	encryption "github.ibm.com/cloud-sre/pnp-data-encryption"
	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		// url          = "amqp://guest:guest@192.168.99.100:5672"
		url          = []string{"amqp://guest:guest@192.168.99.100:5672", "amqp://guest:guest@mytesthost:5670"}
		routingKey   = "case"
		exchangeName = "pnp.direct"
		exchangeType = "direct"
	)

	p := rabbitmq.NewProducer(url, routingKey, exchangeName, exchangeType)

	// Encryption
	encMsg, err := encryption.Encrypt("test msg!! - " + routingKey)
	if err != nil {
		log.Println(err)
	}

	err = p.ProduceOnce(string(encMsg))
	if err != nil {
		log.Println(err)
	}

}
