package main

import (
	"log"

	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		// url          = "amqp://guest:guest@192.168.99.100:5672"
		url          = []string{"amqp://guest:guest@192.168.99.100:5672", "amqp://guest:guest@mytesthost:5670"}
		routingKey   = "nq2ds.incident"
		exchangeName = "pnp.direct"
		exchangeType = "direct"
	)

	p := rabbitmq.NewProducer(url, routingKey, exchangeName, exchangeType)

	err = p.ProduceOnce("test msg - " + routingKey)
	if err != nil {
		log.Println(err)
	}

}
