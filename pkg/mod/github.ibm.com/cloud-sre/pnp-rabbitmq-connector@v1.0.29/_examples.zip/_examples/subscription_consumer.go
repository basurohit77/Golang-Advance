package main

import (
	"log"

	"github.com/streadway/amqp"

	encryption "github.ibm.com/cloud-sre/pnp-data-encryption"
	rabbitmq "github.ibm.com/cloud-sre/pnp-rabbitmq-connector"
)

func main() {
	var (
		// url = "amqp://guest:guest@192.168.99.100:5672"
		url = []string{"amqp://guest:guest@192.168.99.100:5672", "amqp://guest:guest@mytesthost:5670"}
		// qKey holds the list of all queues and routing keys that msgs should be consumed from
		// the string is separated by comma(","), between each comma there a pair of queue:key
		qKey         = "incident.subscription:nq2ds.incident,maintenance.subscription:nq2ds.maintenance,status.subscription:nq2ds.status,case.subscription:nq2ds.case"
		exchangeName = "pnp.direct"
	)

	c := rabbitmq.NewConsumer(url, qKey, exchangeName)

	// set a consumer name, this name will show in the list of consumers in a queue it's consuming from
	// c.Name = "subscriptionConsumer"

	// server automatically acks a msg that is consumed from a queue
	// no need to call msg.Ack(false) if AutoAck is true
	// if not set, the default value is false
	c.AutoAck = true

	log.Fatalln(c.Consume(f))

}

func f(msg amqp.Delivery) {
	log.Printf("msg routing key: `%s`", msg.RoutingKey)
	log.Printf("msg contentType: `%s`", msg.ContentType)
	log.Printf("msg timestamp: `%s` - %s", msg.Timestamp, msg.MessageId)

	// Decryption
	decryptedMsg, err := encryption.Decrypt(msg.Body)
	if err != nil {
		log.Println(err)
	}

	log.Printf("msg: %s", decryptedMsg)

	// ...
	// do something with msg
	// ...

	// do this if you want to send(move) msg to pnp.deadletter.msgs queue
	// you want to do this when there is a bad message
	// if err := msg.Reject(false); err != nil {
	// 	log.Println(err)
	// }

	// send an ack back to mq server that the message was processed
	// if it's not sent, the same msg will still be available for consumption
	// THIS IS NOT NEEDED IF AUTOACK IS TRUE
	// err := msg.Ack(false)
	// if err != nil {
	// 	log.Println(err)
	// }
}
